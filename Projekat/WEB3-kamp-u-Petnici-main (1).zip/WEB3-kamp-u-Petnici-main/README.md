# WEB3 kamp u Petnici, 1 - 10. avgust 2024.
https://web3kamp.org/


## Opšte o kampu



## Whitepapers istraživački rad

Zadatak je bio da se za ~24 h najbolje moguće razume i analizira neka tema odnosno neki Whitepaper. 
Glavni materijal bili su sami Whitepaper radovi i bilo koji drugi naučni radovi koji su dostupni javnosti. 
Kao polaznici, imali smo priliku da odaberemo temu koja nam je zanimljiva, a vezana za WEB3 tehnologije, primarno Blockchain i DeFi. Tema koju sam ja odabrala je Polkadot.
Polkadot je svakako OpenSource, tako da je bilo značajno što je bilo lako pogledati sve njihove resurse.

## Finalni projekat

